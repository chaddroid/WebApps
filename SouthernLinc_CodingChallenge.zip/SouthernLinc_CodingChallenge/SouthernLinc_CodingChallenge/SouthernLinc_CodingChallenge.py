#The following program will read a CSV file and insert those rows into a table in a MYSQLdb.
# Once the records are in the table, we will perform some SQL MATH functions on 3 of those columns and print the output.

import csv
import MySQLdb



chads_db = MySQLdb.connect(host = 'localhost', user = 'pop-user', passwd = 'pop-pw', db = 'popdb')


cursor = chads_db.cursor()


with open('nst-est2016-alldata.csv', mode = 'r') as csvfile:
	csvreader = csv.DictReader(csvfile)
    print('The CSV file has been read and is now ready for insert into the DB')
	for row in csvreader:
		cursor.execute(INSERT INTO Table1(POPESTIMATE2014, POPESTIMATE2013, POPESTIMATE2012)
		print(row)

POPESTIMATE2014_min = cursor.execute(SELECT MIN(POPESTIMATE2014) FROM TABLE1)
print('The Min value of POPESTIMATE2014 is: ',POPESTIMATE2014_min)

POPESTIMATE2013_max = cursor.execute(SELECT MAX(POPESTIMATE2013) FROM TABLE1)
print('The Max value of POPESTIMATE2013 is: ', POPESTIMATE2013_max)

POPESTIMATE2012_mean = cursor.execute(SELECT AVG(POPESTIMATE2012) FROM TABLE1)
print('The mean value of POPESTIMATE2012 is: ', POPESTIMATE2012_mean)

POPESTIMATE2012_sd = cursor.execute(SELECT STDEV(POPESTIMATE2012) FROM TABLE1)
print('The standard deviation of POPESTIMATE2012 is: ', POPESTIMATE2012_sd)

print('All Done')